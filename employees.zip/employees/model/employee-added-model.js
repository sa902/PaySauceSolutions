exports.model = {
    template: 'employee-added',
    context: {
        
    }
}